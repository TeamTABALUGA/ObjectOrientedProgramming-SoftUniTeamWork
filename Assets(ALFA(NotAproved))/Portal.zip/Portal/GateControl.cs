﻿using UnityEngine;
using System.Collections;

public class GateControl : MonoBehaviour {
	
	public float secondsBetweenCreations;
	
	// Components
	public Transform CreatureEjectionPoint;
	public GameObject creature;
	
	//System
	private float nextPosibleShootTime;
	
	void Start(){
		InvokeRepeating("Create", 2, secondsBetweenCreations);
	}
	
	public void Create () {						
		GameObject newShell = Instantiate(creature,CreatureEjectionPoint.position,Quaternion.identity) as GameObject;
	}
}
