﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheSlum
{
    abstract class MyCharacter : Character
    {
        public List<Item> Inventory { get; private set; }
        public Team Team { get; private set; }
        public MyCharacter(string id, int x, int y, int healthPoints, int defensePoints, Team team, int range)
            : base(id, x, y, healthPoints, defensePoints, team, range)
        {
        }

        //public abstract Character GetTarget(IEnumerable<MyCharacter> targetsList);
        //
        //public virtual void AddToInventory(Item item);
        //
        //public abstract void RemoveFromInventory(Item item);
        //
        //protected virtual void ApplyItemEffects(Item item)
        //{
        //    this.HealthPoints += item.HealthEffect;
        //    this.DefensePoints += item.DefenseEffect;
        //}
        //
        //protected virtual void RemoveItemEffects(Item item)
        //{
        //    this.HealthPoints -= item.HealthEffect;
        //    this.DefensePoints -= item.DefenseEffect;
        //    if (this.HealthPoints < 0)
        //    {
        //        this.HealthPoints = 1;
        //    }
        //}
        //
        //public override string ToString()
        //{
        //    return String.Format("Name: {0}, Team: {2}, Health: {1}, Defense: {3}",
        //        this.Id, this.HealthPoints, this.Team.ToString(), this.DefensePoints);
        //}
    }
}
