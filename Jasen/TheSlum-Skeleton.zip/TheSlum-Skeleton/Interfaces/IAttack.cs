﻿using System;

namespace TheSlum.Interfaces
{
    public interface IAttack
    {
        int AttackPoints { get; set; }
    }
}
