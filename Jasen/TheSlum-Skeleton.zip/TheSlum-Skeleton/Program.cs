﻿using System;
using System.Collections.Generic;
using TheSlum.GameEngine;

namespace TheSlum
{
    public class Program 
    {
static void Main(string[] args)
        {
            MyEngine engine = new MyEngine();
        
            engine.Run();
        }
    }
}
